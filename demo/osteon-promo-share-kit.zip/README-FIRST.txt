Osteon - free A&P study in 3D

Open the app: https://rorrimaesu.github.io/osteon-study/
Watch online: https://rorrimaesu.github.io/osteon-study/demo/

osteon-promo.mp4 = 111-second widescreen tour
osteon-promo-social.mp4 = 35-second portrait teaser
Both include narration, music and burned-in captions.
Read PROMO-SHARE.md for post copy and required component credits.
Read PROMO-PRODUCTION.md for the research and checks.
